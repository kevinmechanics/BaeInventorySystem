<?php
/*
Config
*/

$site_name = "B.A.E";
$site_color = "red darken-3";

?>