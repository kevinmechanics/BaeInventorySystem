<!Doctype html>
<html>
	<head>
		<title>Add User Account Utility</title>
	</head>
	<body>
		<h3>Add User Account Utility</h3>
		<form method="post" action="../process/account_add.php">
			<input type="password" name="access_code" placeholder="Access Code"><br>
			<br>
			<input type="text" name="name" placeholder="Name"><br>
			<input type="text" name="username" placeholder="Username"><br>
			<input type="password" name="password" placeholder="Password"><br><br>
			<button type="submit">Submit</button>
		</form>
	</body>
</html>